import React from 'react';
import { BookOpen } from 'lucide-react';
import { MadLibsForm } from './components/MadLibsForm';
import { Story } from './components/Story';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="w-8 h-8 text-indigo-600" />
            <h1 className="text-3xl font-bold text-gray-900">Mad Libs Game</h1>
          </div>
          <p className="text-gray-600 mb-6">
            Fill in the words below and we'll generate a funny story for you!
            Try to be creative with your choices to make the story more
            entertaining.
          </p>
          <MadLibsForm />
        </div>
        <Story />
      </div>
    </div>
  );
}

export default App;