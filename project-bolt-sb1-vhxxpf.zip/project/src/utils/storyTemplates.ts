import { WordType } from '../types';

type StoryTemplate = (words: Record<WordType, string>) => string;

const storyTemplates: StoryTemplate[] = [
  (words) => `Once upon a time, there was a ${words.adjective} ${words.noun} who loved to ${words.verb} ${words.adverb} in ${words.place}. Everyone who visited ${words.place} couldn't believe their eyes!`,
  
  (words) => `In the magical land of ${words.place}, a ${words.adjective} ${words.noun} discovered the incredible ability to ${words.verb} ${words.adverb}. It was a sight to behold!`,
  
  (words) => `Last summer in ${words.place}, I met a ${words.adjective} ${words.noun} who taught me how to ${words.verb} ${words.adverb}. It was the most unusual experience of my life!`,
  
  (words) => `Breaking news from ${words.place}! A ${words.adjective} ${words.noun} has been spotted ${words.verb}ing ${words.adverb}. Local residents are amazed by this unexpected event!`,
];

export const getRandomStoryTemplate = (words: Record<WordType, string>): string => {
  const randomIndex = Math.floor(Math.random() * storyTemplates.length);
  return storyTemplates[randomIndex](words);
};