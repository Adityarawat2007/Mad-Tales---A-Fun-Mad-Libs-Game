import React from 'react';
import { Send } from 'lucide-react';
import { WordInput } from './WordInput';
import { useGameStore } from '../stores/gameStore';
import { WordType } from '../types';

export function MadLibsForm() {
  const { words, setWord, generateStory } = useGameStore();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateStory();
  };

  const requiredWords: { type: WordType; label: string }[] = [
    { type: 'noun', label: 'Noun' },
    { type: 'verb', label: 'Verb' },
    { type: 'adjective', label: 'Adjective' },
    { type: 'adverb', label: 'Adverb' },
    { type: 'place', label: 'Place' },
  ];

  const isFormComplete = Object.values(words).every(word => word.trim() !== '');

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {requiredWords.map(({ type, label }) => (
          <WordInput
            key={type}
            type={type}
            label={label}
            value={words[type]}
            onChange={(value) => setWord(type, value)}
          />
        ))}
      </div>
      <button
        type="submit"
        disabled={!isFormComplete}
        className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
      >
        <Send size={20} />
        Generate Story
      </button>
    </form>
  );
}