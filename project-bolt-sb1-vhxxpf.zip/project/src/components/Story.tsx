import React from 'react';
import { RefreshCw } from 'lucide-react';
import { useGameStore } from '../stores/gameStore';

export function Story() {
  const { story, resetGame } = useGameStore();

  if (!story) return null;

  return (
    <div className="mt-8 bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Your Story</h2>
      <p className="text-gray-700 leading-relaxed mb-6">{story}</p>
      <button
        onClick={resetGame}
        className="flex items-center gap-2 text-indigo-600 hover:text-indigo-700 transition-colors"
      >
        <RefreshCw size={20} />
        Create Another Story
      </button>
    </div>
  );
}