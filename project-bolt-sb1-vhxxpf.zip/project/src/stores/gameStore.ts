import { create } from 'zustand';
import { WordType } from '../types';
import { getRandomStoryTemplate } from '../utils/storyTemplates';

interface GameState {
  words: Record<WordType, string>;
  story: string | null;
  setWord: (type: WordType, value: string) => void;
  generateStory: () => void;
  resetGame: () => void;
}

const initialWords: Record<WordType, string> = {
  noun: '',
  verb: '',
  adjective: '',
  adverb: '',
  place: '',
};

export const useGameStore = create<GameState>((set) => ({
  words: initialWords,
  story: null,
  setWord: (type, value) =>
    set((state) => ({
      words: { ...state.words, [type]: value },
    })),
  generateStory: () =>
    set((state) => ({
      story: getRandomStoryTemplate(state.words),
    })),
  resetGame: () =>
    set(() => ({
      words: initialWords,
      story: null,
    })),
}));